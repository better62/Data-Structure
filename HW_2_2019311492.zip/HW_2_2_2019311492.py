class BST_array:  # Binary Search Tree 클래스 생성
    def __init__(self, n):
        self.n = n  # 저장할 데이터 수(해당 문제에서는 10개)
        self.tree = [[None, None] for _ in range(2**self.n-1)]  # 저장할 데이터 개수만큼 트리 초기화 : [key, value]

    def search(self, key, index=0):  # 탐색 함수
        if self.tree[0][0] == None: # 루트 노드가 비었을 때 (빈 트리)
            print("트리가 비었습니다.") # 해당 출력문 실행
        if self.tree[index][0] != None: # 노드가 비지 않았을 때
            if self.tree[index][0] < key:   # key 값이 해당 노드의 키 값보다 큰 경우
                self.search(key, 2*(index+1))   # 해당 노드의 오른쪽 자식에서 탐색 수행
            elif self.tree[index][0] > key: # key 값이 해당 노드의 키 값보다 작은 경우
                self.search(key, 2*index+1) # 해당 노드의 왼쪽 자식에서 탐색 수행
            else:   # key 값과 해당 노드의 키 값이 같은 경우
                print("탐색된 노드의 키 값 : "+str(self.tree[index][0])+", 탐색된 노드의 value 값 : "+str(self.tree[index][1]))  # 탐색 성공 : value 출력

    def insert_tree(self, key, value, index=0): # 트리에 노드 삽입
        if self.tree[0][0] == None: # 만약 루트 노드가 비었으면
            self.tree[0][0] = key   # 루트 노드에 키 삽입
            self.tree[0][1] = value # 루트 노드에 value 삽입
            return
        if self.tree[index][0] < key:   # 만약 삽입하고자 하는 key가 부모 노드의 key보다 크면
            self._insert_right(key, value, index)   # 오른쪽에 삽입
        elif self.tree[index][0] > key: # 삽입하고자 하는 key가 부모 노드의 key보다 작으면
            self._insert_left(key, value, index)    # 왼쪽에 삽입

    def _insert_right(self, key, value, index): # 오른쪽에 삽입하는 함수
        index = 2*(index+1) # 오른쪽 자식 노드의 인덱스
        if self.tree[index][0] != None: # 오른쪽 자식노드가 비어있지 않을 때
            if self.tree[index][0] == key:  # 오른쪽 자식노드가 삽입하고자 하는 데이터의 키 값과 같을 때
                self.tree[index][1] = value # value update
            self.insert_tree(key, value, index) # 다음 level에 삽입하기 위해 insert_tree 함수 호출
        else:   # 만약 오른쪽 자식노드가 비었다면
            self.tree[index][0] = key   # 해당 위치에 key 삽입
            self.tree[index][1] = value # value 삽입

    def _insert_left(self, key, value, index):  # 왼쪽에 삽입하는 함수
        index = 2*index +1  # 왼쪽 자식 노드의 인덱스
        if self.tree[index][0] != None: # 왼쪽 자식노드가 비어있지 않을 때
            if self.tree[index][0] == key:  # 왼쪽 자식노드가 삽입하고자 하는 데이터의 키 값과 같을 때
                self.tree[index][1] = value # value update
            self.insert_tree(key, value, index) # 다음 level에 삽입하기 위해 inser_tree 함수 호출
        else:
            self.tree[index][0] = key   # 해당 위치에 key 삽입
            self.tree[index][1] = value # value 삽입

    def delete_tree(self, key): # 삭제 함수
        if self.tree[0][0] == None: # 만약 트리가 비었다면
            return None # None 반환
        for i in range(len(self.tree)): # 트리를 순회하면서
            if self.tree[i][0] == key:  # 만약 해당 노드의 key값이 찾고자 하는 key와 같다면 (삭제 수행)
                if self.tree[2*i+1][0] != None :    # 해당 노드의 왼쪽 자식노드에 데이터가 있을 때
                    self.tree[i] = self.tree[2*i+1] # 왼쪽 자식 노드를 해당 노드로 연결
                    self.tree[2*i+1] = [None, None] # 기존 왼쪽 자식 노드 데이터 None으로 변환
                else:   # 해당 노드의 왼쪽 자식노드에 데이터가 없을 때
                    if self.tree[2*(i+1)] != None:  # 오른쪽 자식노드는 존재한다면
                        self.tree[i] = self.tree[2*(i+1)]    # 오른쪽 자식 노드를 해당 노드로 연결
                        self.tree[2*(i+1)] = [None, None]   # 기존 오른쪽 자식 노드 데이터 None으로 변환
                    else:   # 왼쪽 자식노드, 오른쪽 자식노드 모두 존재하지 않는다면 (말단노드)
                        self.tree[i] = [None, None] # 해당 노드의 데이터를 None으로 변환
                return
        return None    # 만약 트리에서 삭제할 데이터를 찾지 못했다면 None 반환

    def preorder(self, index):  # 전위순회
        if self.tree[index][0] != None:   # 트리의 노드가 None이 아니라면
            print(str(self.tree[index][0]), ' ', end=' ')    # 해당 노드를 방문하여 값 출력
            if self.tree[2*index+1][0] != None:  # 노드의 왼쪽 자식 노드가 None이 아니면
                self.preorder(2*index+1)   # 노드의 왼쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            if self.tree[2*(index+1)][0] != None: # 노드의 오른쪽 자식 노드가 None이 아니면
                self.preorder(2*(index+1))  # 노드의 오른쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출

    def postorder(self, index): # 후위순회
        if self.tree[index][0] != None:   # 노드가 None이 아니라면
            if self.tree[2 * index + 1][0] != None:  # 노드의 왼쪽 자식 노드가 None이 아니면
                self.postorder(2 * index + 1)  # 노드의 왼쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            if self.tree[2 * (index + 1)][0] != None:  # 노드의 오른쪽 자식 노드가 None이 아니면
                self.postorder(2 * (index + 1))  # 노드의 오른쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            print(str(self.tree[index][0]), ' ', end=' ')    # 노드의 값 출력

    def inorder(self, index):   # 중위순회
        if self.tree[index][0] != None:   # 노드가 None이 아니라면
            if self.tree[2*index+1][0] != None:  # 노드의 왼쪽 자식 노드가 존재하면
                self.inorder(2*index+1)    # 노드의 왼쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            print(str(self.tree[index][0]), ' ', end=' ')    # 노드를 방문하여 값 출력
            if self.tree[2*(index+1)][0] != None: # 노드의 오른쪽 자식 노드가 존재하면
                self.inorder(2*(index+1))   # 노드의 오른쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출

    def levelorder(self): # 레벨순회
        for i in range(len(self.tree)):
            if self.tree[i][0] != None:
                print(str(self.tree[i][0]), ' ', end=' ')    # 노드를 방문하여 값 출력

    def print_tree(self):
        print(self.tree)

import random   # 랜덤 수 생성을 위함
random.seed(50)

def traversal(BST):    # Traversal
    print("전위순회")   # 전위순회 - 전위순회 함수 호출
    BST.preorder(0)
    print("\n후위순회") # 후위순회 - 후위순회 함수 호출
    BST.postorder(0)
    print("\n중위순회") # 중위순회 - 중위순회 함수 호출
    BST.inorder(0)
    print("\n레벨순회") # 레벨순회 - 레벨순회 함수 호출
    BST.levelorder()
    print("\n"+"-"*60)

key = []    # 키 값을 저장할 리스트 초기화
value = []  # value 값을 저장할 리스트 초기화

BST = BST_array(10) # Binary Search Tree 객체 생성 (10개의 key, value set)

for _ in range(10): # 반복문을 10번 돌면서
    # 난수를 키 리스트, value 리스트에 append
    key.append(random.randint(0, 100))
    value.append(random.randint(0, 100))

# 각 리스트 출력
print("key list :", key)
print("value list :", value)

for i in range(10): # 10번 반복하여
    BST.insert_tree(key[i], value[i])   # 삽입 연산 수행

# 삽입 후 트리 출력
print("\n10개의 item 삽입 후 트리")
BST.print_tree()    # naive 트리 출력
traversal(BST) # 순회

delete_list = random.sample(key, 3) # 삭제 할 노드를 랜덤으로 생성(키 값 기준, 3개)
print("삭제할 키 리스트 :", delete_list)   # 삭제할 키 리스트 출력
for i in delete_list:   # 키 리스트를 돌면서
    BST.delete_tree(i)  # 삭제 수행

# 삭제 후 트리 출력
print("\n3개의 item 삭제 후 트리")
BST.print_tree()    # naive 트리 출력
traversal(BST) # 순회

search_list = random.sample(key, 2) # 탐색 할 노드를 랜덤으로 생성(키 값 기준, 2개)
for i in search_list:   # 탐색 리스트를 돌면서
    print("\n"+"key : "+str(i)+" -> 탐색")    # 어떤 노드를 탐색할지 출력
    BST.search(i)  # 탐색 수행


