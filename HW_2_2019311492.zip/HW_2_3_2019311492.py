from linked_based_BST import BST_linked
from array_based_BST import BST_array
import random
import time
import matplotlib.pyplot as plt

random.seed(300)  # 랜덤 시드 설정

bst_linked = BST_linked()
# 노드 개수 리스트 (5~20까지의 노드를 가진 BST를 생성할 예정)
num = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

# 그래프 생성을 위한 title list
best_time_name = ["insert_time_arr(best case)", "delete_time_arr(best case)", "search_time_arr(best case)",
                  "insert_time_linked(best case)", "delete_time_linked(best case)", "search_time_linked(best case)"]
worst_time_name = ["insert_time_arr(worst case)", "delete_time_arr(worst case)", "search_time_arr(worst case)",
                  "insert_time_linked(worst case)", "delete_time_linked(worst case)", "search_time_linked(worst case)"]

# 측정한 시간을 저장하기 위한 리스트 초기화
# best case (balanced tree)
insert_time_arr = []
delete_time_arr = []
search_time_arr = []
insert_time_linked = []
delete_time_linked = []
search_time_linked = []
best_time_list = [insert_time_arr, delete_time_arr, search_time_arr, insert_time_linked, delete_time_linked,
                 search_time_linked]

# worst case (skewed tree)
insert_time_arr_w = []
delete_time_arr_w = []
search_time_arr_w = []
insert_time_linked_w = []
delete_time_linked_w = []
search_time_linked_w = []
worst_time_list = [insert_time_arr_w, delete_time_arr_w, search_time_arr_w, insert_time_linked_w, delete_time_linked_w,
                 search_time_linked_w]


# best key list를 생성하기 위해 정렬된 array의 중간값을 반환하는 함수 생성
def return_mid(arr):
    if len(arr) == 0:   # 빈 array이면
        return  # 아무것도 리턴하지 않음
    return arr[len(arr)//2] # 비어있지 않으면 중간 인덱스의 값 반환

def run_time(key, value, is_best):  # 시간 측정 함수
    # Linked base BST와 array based BST 초기화
    bst_linked = BST_linked()
    bst_arr = BST_array(21)

    # 반복문을 통해 BST 생성
    for j in range(len(key)):
        bst_arr.insert_tree(key[j], value[j])
        bst_linked.put(key[j], value[j])
    new_key = random.randint(0, 100)    # 랜덤으로 삽입할 new_key 변수 생성
    new_value = random.randint(0, 100)  # 랜덤으로 삽입할 new_value 변수 생성
    delete_key = random.sample(key, 1)  # 랜덤으로 삭제할 delete_key 변수 생성
    search_key = random.sample(key, 1)  # 랜덤으로 탐색할 search_key 변수 생성

    # BST_array - 삽입
    start = time.perf_counter() # 시작 시간 측정
    bst_arr.insert_tree(new_key, new_value) # 랜덤으로 생성한 new_key, new_value 삽입
    end = time.perf_counter()   # 끝 시간 측정
    if is_best == 1:    # 만약 best case이면
        insert_time_arr.append(end-start)   # best case time을 저장하는 리스트에 append
    else:   # worst case이면
        insert_time_arr_w.append(end-start) # worst case time을 저장하는 리스트에 append

    # BST_array - 삭제
    start = time.perf_counter() # 시작 시간 측정
    bst_arr.delete_tree(delete_key[0])  # 랜덤으로 하나 삭제
    end = time.perf_counter()   # 끝 시간 측정
    if is_best == 1:    # 만약 best case이면
        delete_time_arr.append(end - start) # best case time을 저장하는 리스트에 append
    else:   # worst case이면
        delete_time_arr_w.append(end - start)   # worst case time을 저장하는 리스트에 append

    # BST_array - 탐색
    start = time.perf_counter() # 시작 시간 측정
    bst_arr.search(search_key[0])   # 랜덤으로 하나 탐색
    end = time.perf_counter()   # 끝 시간 측정
    if is_best == 1:    # 만약 best case이면
        search_time_arr.append(end-start)   # best case time을 저장하는 리스트에 append
    else:   # worst case이면
        search_time_arr_w.append(end-start) # worst case time을 저장하는 리스트에 append

    # BST_linked - 삽입
    start = time.perf_counter() # 시작 시간 측정
    bst_linked.put(new_key, new_value)  # 랜덤으로 생성한 new_key, new_value 삽입
    end = time.perf_counter()   # 끝 시간 측정
    if is_best == 1:    # 만약 best case 이면
        insert_time_linked.append(end - start)  # best case time을 저장하는 리스트에 append
    else:   # worst case이면
        insert_time_linked_w.append(end - start)    # worst case time을 저장하는 리스트에 append

    # BST_linked - 삭제
    start = time.perf_counter() # 시작 시간 측정
    bst_linked.delete(delete_key[0])    # 랜덤으로 하나 삭제
    end = time.perf_counter()   # 끝 시간 측정
    if is_best == 1:    # 만약 best case 이면
        delete_time_linked.append(end - start)  # best case time을 저장하는 리스트에 append
    else:   # worst case이면
        delete_time_linked_w.append(end - start)    # worst case time을 저장하는 리스트에 append

    # BST_linked - 탐색
    start = time.perf_counter() # 시작 시간 측정
    bst_linked.get(search_key[0])   # 랜덤으로 하나 탐색
    end = time.perf_counter()   # 끝 시간 측정
    if is_best == 1:    # 만약 best case 이면
        search_time_linked.append(end - start)  # best case time을 저장하는 리스트에 append
    else:   # worst case이면
        search_time_linked_w.append(end - start)    # worst case time을 저장하는 리스트에 append

def graph(time_list, index, time_list_name):    # graph와 평균 실행 시간 구하는 함수
    title = time_list_name[index]
    plt.title(title)    # 위의 인덱스 별로 그래프 타이틀 설정
    print("-"*50)
    print(title+" :", time_list)    # 전체 실행시간 리스트 출력
    plt.plot(num, time_list)  # 그래프 생성
    plt.show()  # 그래프 출력
    print("Average of "+title+" :", sum(time_list)/len(time_list))  # 실행시간 평균 출력

print("-"*20+"3번 문제"+"-"*20)
for i in num:   # 노드의 개수(5~20)만큼 best case / worst case 생성
    best_key = []   # best_key를 저장할 리스트 초기화
    worst_key = []  # worst_key를 저장할 리스트 초기화
    value = []  # value를 저장할 리스트 초기화

    # worst case는 키가 오름차순으로 삽입되면 된다.(skewed BST)
    for j in range(i):
        worst_key.append(j)
        value.append(random.randint(0, 100))

    worst_key_copied = worst_key.copy() # best case 생성을 위해 리스트 copy

    index = i//2    # 루트(중간 값)을 지정하기 위한 index
    best_key.append(worst_key_copied.pop(index))    # 중간값을 pop하고 이를 best_key에 append

    while True: # 나머지 값들도 best_key list에 하나씩 삽입
        if index == 0:  # index가 0이 될때까지 반복
            break
        # index를 기준으로 왼쪽, 오른쪽 구분
        left = worst_key[:index]
        right = worst_key[index+1:]
        temp = return_mid(left) # 왼쪽에서 중간값을 구함
        # 만약 그 중간값이 키 리스트에 없으면 append
        if temp not in best_key:
            best_key.append(temp)
        worst_key_copied.remove(temp)   # 복사한 리스트에서 해당 값 삭제

        temp = return_mid(right)    # 오른쪽에서 중간값을 구함
        # 만약 그 중간값이 키 리스트에 없으면 append
        if temp not in best_key:
            best_key.append(temp)
        # 만약 복사한 리스트에서 해당값이 없으면 삭제
        if temp in worst_key_copied:
            worst_key_copied.remove(temp)
        # index // 2
        index = index//2

    # 만약에 기존의 key 리스트가 짝수였다면 위의 반복문 실행 후 삽입되지 않은 키가 발생 -> 순서대로 best key list에 append
    # 짝수인 경우에 위의 현상이 발생하는 이유는 처음에 루트 노드를 먼저 삽입해주었기 때문에 남은 키가 홀수 개이기 때문
    if len(worst_key_copied) != 0:
        for i in worst_key_copied:
            best_key.append(i)

    # best key, worst key 출력
    print("best key :", best_key)
    print("worst key :", worst_key)

    # best case 일 때 실행시간 함수 호출
    run_time(best_key, value, 1)
    # worst case 일 때 실행시간 함수 호출
    run_time(worst_key, value, 0)

    print("-"*60)

# 그래프 생성
for idx, i in enumerate(best_time_list):
    graph(i, idx, best_time_name)
for idx, i in enumerate(worst_time_list):
    graph(i, idx, worst_time_name)