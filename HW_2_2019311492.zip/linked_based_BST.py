class Node: # 노드 클래스 생성
    def __init__(self, key, value, left=None, right=None):
        self.key = key  # 노드 키 초기화
        self.value = value  # 노드 값 초기화
        self.left = left    # 노드의 왼쪽 자식 초기화
        self.right = right  # 노드의 오른쪽 자식 초기화

class BST_linked:  # BST 클래스 생성
    def __init__(self):
        self.root = None    # 트리 루트 초기화

    def get(self, k): # 탐색 연산 수행
        return self.get_item(self.root, k)

    def get_item(self, n, k):   # 탐색 연산 수행 (n은 노드, k는 찾고자 하는 값)
        if n == None:   # 탐색 실패
            return None # None 반환
        if n.key > k:   # k가 노드의 key보다 작으면
            return self.get_item(n.left, k) # 왼쪽 서브트리 반환
        elif n.key < k: # k가 노드의 key보다 크면
            return self.get_item(n.right, k)    # 오른쪽 서브트리 반환
        else:   # k와 노드의 key가 같으면
            return n.value  # 노드의 값 반환

    def put(self, k, v):    # 삽입 연산 수행
        self.root = self.put_item(self.root, k, v)    # 루트와 put_item 함수의 반환 값 연결

    def put_item(self, n, k, v):    # 삽입 연산 수행
        if n == None:   # n이 None이면
            return Node(k, v) # 새로운 노드 생성
        if n.key > k:   # 노드의 key가 k보다 크면
            n.left = self.put_item(n.left, k, v)    # n의 왼쪽 자식과 put_item 반환값 연결
        elif n.key < k: # 노드의 key보다 k가 크면
            n.right = self.put_item(n.right, k, v)  # n의 오른쪽 자식과 put_item 반환값 연결
        else:   # k라는 키가 이미 존재할 때
            n.value = v # value 업데이트
        return n    # 노드 n 반환

    def delete(self, k):    # 삭제 연산 수행
        self.root = self.del_node(self.root, k) # 루트와 del_node 함수의 반환값 연결

    def minimum(self, n):
        if n.left == None:  # 왼쪽 자식이 None이면
            return n    # 해당 노드 반환
        return self.minimum(n.left) # 왼쪽 자식으로 재귀호출

    def del_min(self, n):
        if n.left == None:   # 왼쪽 자식이 None이면(최솟값을 가진 노드이면)
            return n.right  # 그 노드의 오른쪽 자식을 반환
        # 왼쪽 자식이 None이 아니면
        n.left = self.del_min(n.left)   # 왼쪽 자식과 왼쪽 자식으로 재귀호출 했을 때의 반환값 연결
        return n    # 삭제가 끝난 후 노드 반환

    def del_node(self, n, k):
        if n == None:   # 삭제하려는 노드가 None일 때
            return None # None 반환
        if n.key > k:   # 노드의 key가 k보다 클 때
            n.left = self.del_node(n.left, k)   # n의 왼쪽 자식과 del_node의 반환값 연결
        elif n.key < k: # 노드의 key보다 k가 클 때
            n.right = self.del_node(n.right, k) # n의 오른쪽 자식과 del_node의 반환값 연결
        else:   # 만약 노드의 키와 k가 같을 때
            if n.right == None: # 만약 노드의 오른쪽 자식이 없다면
                return n.left   # 왼쪽 자식 반환
            if n.left == None:  # 만약 노드의 왼쪽 자식이 없다면
                return n.right  # 오른쪽 자식 반환
            target = n  # 삭제하고자 하는 노드인 n을 target에 할당
            min = self.minimum(target.right)  # target의 오른쪽 자식에서 최솟값을 찾아 min에 할당
            min.right = self.del_min(target.right)  # min의 오른쪽 자식을 target의 최솟값 삭제 후와 연결
            min.left = target.left  # min의 왼쪽 자식을 target의 왼쪽 자식으로
        return n    # 노드 삭제 후 반환

    def preorder(self, n):  # 전위순회
        if n != None:   # n이 None이 아니라면
            print(str(n.key), ' ', end=' ')    # n을 방문하여 값 출력
            if n.left:  # n의 왼쪽 자식 노드가 None이 아니면
                self.preorder(n.left)   # n의 왼쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            if n.right: # n의 오른쪽 자식 노드가 None이 아니면
                self.preorder(n.right)  # n의 오른쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출

    def postorder(self, n): # 후위순회
        if n != None:   # n이 None이 아니라면
            if n.left:  # n의 왼쪽 자식 노드가 존재하면
                self.postorder(n.left)  # n의 왼쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            if n.right: # n의 오른쪽 자식 노드가 존재하면
                self.postorder(n.right) # n의 오른쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            print(str(n.key), ' ', end=' ')    # n의 값 출력

    def inorder(self, n):   # 중위순회
        if n != None:   # n이 None이 아니라면
            if n.left:  # n의 왼쪽 자식 노드가 존재하면
                self.inorder(n.left)    # n의 왼쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출
            print(str(n.key), ' ', end=' ')    # n을 방문하여 값 출력
            if n.right: # n의 오른쪽 자식 노드가 존재하면
                self.inorder(n.right)   # n의 오른쪽 자식 노드를 루트로 하는 서브트리를 재귀 호출

    def levelorder(self, root): # 레벨순회
        q = []  # 빈 큐 생성
        q.append(root)  # 루트 노드 enqueue
        while len(q) != 0:  # 큐가 empty가 될 때까지 반복
            t = q.pop(0)    # 노드를 dequeue 한 후
            print(str(t.key), ' ', end=' ')   # 출력
            if t.left != None:  # t의 왼쪽 자식 노드가 None이 아니라면
                q.append(t.left)    # 큐에 왼쪽 자식 노드를 enqueue
            if t.right != None: # t의 오른쪽 자식 노드가 None이 아니라면
                q.append(t.right)   # 큐에 오른쪽 자식 노드를 enqueue