"""
DFS
"""
def DFS(graph, v, visited):
    visited.append(v)   # 해당 정점을 방문 리스트에 추가
    for i in range(len(graph)): # 그래프를 순회하면서
        if graph[v][i] and i not in visited:    # 정점에 인접한 모든 정점에 대해 방문하지 않았다면
            visited = DFS(graph, i, visited)    # recursion 수행
    return visited

"""
BFS
"""
def BFS(graph, v):
    q = [v] # current node를 저장하기 위해 (초기화)
    visited = [v]   # 해당 정점을 방문 리스트에 추가
    while q:    # current node queue에서
        current_node = q.pop(0) # pop 연산을 수행하고
        for i in range(len(graph)): # graph에서
            if graph[current_node][i] and i not in visited: # current node와 인접하지만 방문하지 않은 정점들을
                q.append(i) # current node queue에 추가
                visited.append(i)   # visited 리스트에 추가
    return visited

def print_graph(output):    # 그래프 출력
    dic = {0:'A', 1:'B', 2:'C', 3:'D', 4:'E'}   # 5X5 matrix

    for i in range(len(output)-1):  # DFS/BFS 결과를 순회하며 알파벳으로 출력
        print(dic[output[i]]+'-> ', end="")
    print(dic[output[len(output)-1]], end="")

# 인접 행렬
graph = [
    [0, 1, 1, 0, 1],
    [1, 0, 1, 0, 0],
    [1, 1, 0, 1, 1],
    [0, 0, 1, 0, 1],
    [1, 0, 1, 1, 0]
]

dfs = DFS(graph, 0, []) # DFS 수행
print("DFS using adjacency matrix")
print_graph(dfs)    # 결과 출력
print("\nBFS using adjacency matrix")   # BFS 수행
bfs = BFS(graph, 0)
print_graph(bfs)    # 결과 출력
