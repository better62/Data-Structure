from collections import deque
import random
import time
import matplotlib.pyplot as plt
import numpy as np

random.seed(300)

"""
Selection sort
"""
def selection_sort(items):
    for i in range(0, len(items)-1):    # 리스트의 마지막 인덱스 전까지만 i 증가
        minimum = i # 최솟값 인덱스 초기화
        for j in range(i, len(items)):# 정렬이 끝난 앞부분을 제외하고 정렬이 필요한 부분만
            if items[minimum] > items[j]:   # 만약 기존의 최솟값보다 더 작으면
                minimum = j # 최솟값 인덱스 업데이트
        items[i], items[minimum] = items[minimum], items[i] # 최솟값과 자리 바꿈


"""
Bubble sort
"""

def bubble_sort(items):
    for i in range(len(items)): # 리스트의 크기만큼 반복
        # 리스트의 총 크기에서 i의 값과 1을 뺀 만큼 반복
        for j in range(0, len(items)-i-1):
            if items[j] > items[j + 1]: # 현재 값이 다음 값보다 클 때
                items[j], items[j + 1] = items[j + 1], items[j]  # 자리 바꿈
    
"""
Quick sort
"""
def quick_sort(items, is_best):
    if len(items) <= 1: # 리스트 원소의 개수가 1이면
        return items    # 리스트 반환

    if is_best == False: # worst case일 경우
        pivot = items[-1]   # pivot을 리스트의 가장 오른쪽에 위치한 값으로
    else:
        pivot = items[len(items) // 2]  # pivot을 리스트 중간에 위치한 값으로


    left, mid, right = [], [], []   # 각 리스트 초기화
    for num in items:   # 리스트 순회
        if num < pivot: # pivot보다 작으면 왼쪽에
            left.append(num)
        elif num > pivot:   # pivot보다 크면 오른쪽에
            right.append(num)
        else:   # 같으면 중간에
            mid.append(num)

    return quick_sort(left, is_best) + mid + quick_sort(right, is_best)   # 각각 재귀호출 후 합치기

"""
Merge sort
"""
def merge(items, temp, low, mid, high):
    i = low
    j = mid+1
    # 임시로 합병된 결과를 저장하기 위한 리스트 temp에 모든 원소가 저장될 때까지 반복
    for k in range(low, high+1):
        if i > mid: # items의 앞부분 원소들을 전부 temp에 저장했다면
            temp[k] = items[j]  # 뒷부분 남은 원소들을 차례로 temp에 저장
            j += 1
        elif j > high:  # items의 뒷부분 원소들을 전부 temp에 저장했다면
            temp[k] = items[i]  # 앞부분 남은 원소들을 차례로 temp에 저장
            i += 1
        elif items[j] < items[i]:   # items[j] 값이 items[i] 값보다 작으면
            temp[k] = items[j]  # temp[k]에 items[j]를 저장
            j += 1  # j 1 증가
        else:   # items[i] 값이 items[j] 값보다 작으면
            temp[k] = items[i]  # temp[k]에 items[i]를 저장
            i += 1  # i 1 증가
    for k in range(low, high+1):    # temp에 모든 원소가 저장 되어 라인 4 for-루프를 탈출했다면
        items[k] = temp[k]  # temp의 내용을 items에 복사

def merge_sort(items, temp, low, high):
    # items가 하나의 원소로 이루어졌다면, None값 반환 후 종료
    if high <= low:
        return None
    mid = low + (high - low) // 2   # items의 중간 원소의 인덱스 계산
    merge_sort(items, temp, low, mid)   # items의 앞부분에 대해 merge_sort 호출 (재귀 호출)
    merge_sort(items, temp, mid+1, high)    # items의 뒷부분에 대해 merge_sort 호출 (재귀 호출)
    merge(items, temp, low, mid, high)  # merge 함수를 이용하여 합병 및 정렬

"""
Radix sort
"""
def counting_sort(items, exp):
    n = len(items)
    max = 9 # 십진수 사용
    count = [0]*(max+1) # count 리스트 초기화
    output = [-1]*n # output 초기화

    for i in items:
        index = int((i/exp)%10) # count 리스트의 인덱스 구하기
        count[index] += 1   # 1 더해주기

    for i in range(max):    # count update
        count[i+1] += count[i]

    for i in range(n-1, -1, -1):
        index = int((items[i]/exp)%10)     # index 구한 후
        output[count[index]-1] = items[i]   # output에 item 넣고
        count[index] -= 1   # count 감소

    for i in range(0, n):   # 기존 데이터 리스트에 차례로 넣어주기
        items[i] = output[i]

    return items

def radix_sort(items):
    max1 = max(items)   # 입력으로 들어온 리스트에서 최댓값 찾기

    exp = 1 # 자릿수를 저장하기 위해
    while int(max1/exp) > 0:    # 각 자릿수 별로
        counting_sort(items, exp)   # counting_sort 호출
        exp *= 10   # 다음 자릿수로

def make_case(num):
    temp = []  # 0~100의 랜덤 수가 num개 있는 리스트 생성 (중복된 원소 없음)
    while len(temp) <= num:  # num개의 원소가 있는 리스트를 생성
        a = random.randint(0, 100)  # 랜덤 수 추출
        if a not in temp:  # 리스트에 해당 랜덤 수가 존재하지 않으면
            temp.append(a)  # 리스트에 랜덤 수 추가
    best = sorted(temp)  # best case는 이미 정렬 완료된 리스트 (오름차순)
    worst = sorted(temp, reverse=True)  # worst case는 반대로 정렬된 리스트 (내림차순)

    return best, temp, worst

def make_case_radix(num):
    avg = []   # 중복된 원소 없이 num개의 원소가 있는 리스트
    best = []   # best case

    for i in range(11, num+11):    # num 개수만큼 두 자리 수 생성
        best.append(i)  # 하나씩 append

    while len(avg) <= num:  # num개의 원소가 있는 리스트를 생성
        a = random.randint(0, 1000)  # 랜덤 수 추출
        if a not in avg:  # 리스트에 해당 랜덤 수가 존재하지 않으면
            avg.append(a)  # 리스트에 랜덤 수 추가

    worst = best[:]
    worst.pop()   # best에서 하나를 뺀 후
    worst.append(1234567)    # 자릿수가 다르고 큰 수 하나 append

    return best, avg, worst


def compute_time(items, kind, is_best=True):  # 실행 시간 측정 함수
    start = time.perf_counter() # 시작 시간
    if kind == "selection": # selection sort 수행
        selection_sort(items)
    elif kind == "bubble":  # bubble sort 수행
        bubble_sort(items)
    elif kind == "quick":   # quick sort 수행
        if is_best == False:
            quick_sort(items, False)
        else:
            quick_sort(items, True)
    elif kind == "merge":   # merge sort 수행
        temp = [None] * len(items)
        merge_sort(items, temp, 0, len(items) - 1)
    else:   # radix sort 수행
        radix_sort(items)
    end = time.perf_counter()   # 실행 후 시간

    return end-start

if __name__ == "__main__":
    num = [10, 20, 30, 40, 50]
    kind = ["selection", "bubble", "quick", "merge", "radix"]

    for k in kind:
        best_time = []
        avg_time = []
        worst_time = []
        for n in num:
            if k != "radix":
                best, avg, worst = make_case(n)
            else:
                best, avg, worst = make_case_radix(n)

            b = compute_time(best, k)
            best_time.append(b)
            a = compute_time(avg, k)
            avg_time.append(a)
            w = compute_time(worst, k, False)
            worst_time.append(w)


        print(k+" sort (원소 개수 각 10, 20, 30, 40, 50) ")
        print("best time list :", best_time)
        print("average best time :", np.mean(best_time))
        print("avg time list :", avg_time)
        print("average average time :", np.mean(avg_time))
        print("worst time list :", worst_time)
        print("average worst time :", np.mean(worst_time))

        plt.title(k +" sort (best time)")
        plt.plot(num, best_time)
        plt.show()

        plt.title(k + " sort (avg time)")
        plt.plot(num, avg_time)
        plt.show()

        plt.title(k + " sort (worst time)")
        plt.plot(num, worst_time)
        plt.show()
