import time
import random

"""
array 기반
"""

def random_stack(n):    # n개의 요소가 있는 random 스택 생성 함수
    stack = []  # 빈 스택 선언
    for i in range(n):  # n 만큼 반복
        stack.append(random.randint(0, 1000))   # 랜덤 수 append
    return stack    # 랜덤 스택 반환

def run_time_array(): # 실행 시간 측정
    push_time = []  # push 연산 실행 시간 저장하는 리스트
    pop_time = []   # pop 연산 실행 시간 저장하는 리스트
    # stack의 요소 개수는 1부터 10000까지
    for i in range(1, 10001):
        stack = random_stack(i) # i개 요소의 랜덤 스택 생성
        start = time.perf_counter() # push 연산 전 시간 측정
        stack.append(1)  # push 연산
        end = time.perf_counter()   # push 연산 후 시간 측정
        push_time.append(end-start) # 측정한 시간 append
        start = time.perf_counter() # pop 연산 전 시간 측정
        stack.pop(-1)   # pop 연산
        end = time.perf_counter()   # pop 연산 후 시간 측정
        pop_time.append(end-start)  # 측정한 시간 append
    return push_time, pop_time  # 각 리스트를 반환

push_time_arr, pop_time_arr = run_time_array()    # 실행 시간 측정 함수 호출

#######################################################
#######################################################
#######################################################
"""
linked list 기반
"""

class Node: # 노드 클래스 생성
    def __init__(self, item, link): # 노드 생성자
        self.item = item    # 항목
        self.next = link    # 다음 레퍼런스

def push(item): # stack 삽입 연산 수행하는 함수
    global top  # 전역변수로 top 변수 선언(stack의 가장 위 요소)
    global size # 전역변수로 스택의 사이즈 변수 선언
    top = Node(item, top)   # top을 다음 레퍼런스로 하는 노드 생성 후 연결리스트의 첫 노드로 삽입
    size += 1   # 삽입 연산 수행 후 사이즈 1 늘이기

def pop():  # stack 삭제 연산 수행하는 함수
    global top  # 전역변수로 top 변수 선언(stack의 가장 위 요소)
    global size  # 전역변수로 스택의 사이즈 변수 선언
    if size != 0:   # 만약 스택이 비어있지 않다면
        top_item = top.item # top item을 변수에 저장
        top = top.next  # top 다음 요소를 top으로
        size -= 1   # 삭제 연산 수행 후 사이즈 1 줄이기
        return top_item # top item 반환

def random_stack_list(n):    # n개의 요소가 있는 random 스택 생성 함수
    global top  # 전역변수로 top 변수 선언(stack의 가장 위 요소)
    global size  # 전역변수로 스택의 사이즈 변수 선언
    top = None  # top 초기화
    size = 0  # 사이즈 초기화
    for i in range(n):  # n 만큼 반복
        push(random.randint(0, 1000))   # 랜덤 수 push

def run_time_list(): # 실행 시간 측정
    push_time = []  # push 연산 실행 시간 저장하는 리스트
    pop_time = []   # pop 연산 실행 시간 저장하는 리스트
    # stack의 요소 개수는 1부터 10000까지
    for i in range(1, 10001):
        random_stack_list(i) # i개 요소의 랜덤 스택 생성
        start = time.perf_counter() # push 연산 전 시간 측정
        push(1)  # push 연산
        end = time.perf_counter()   # push 연산 후 시간 측정
        push_time.append(end-start) # 측정한 시간 append
        start = time.perf_counter()  # pop 연산 전 시간 측정
        pop()   # pop 연산
        end = time.perf_counter()   # pop 연산 후 시간 측정
        pop_time.append(end-start)  # 측정한 시간 append
    return push_time, pop_time  # 각 리스트를 반환

push_time_list, pop_time_list = run_time_list()    # 실행 시간 측정 함수 호출

"""
각 실행시간 비교를 위해 그래프 그리기
"""
import matplotlib.pyplot as plt

x = []
for i in range(1, 10001):   # 그래프 x 축 생성
    x.append(i)

def graph(time_list, index):    # graph와 평균 실행 시간 구하는 함수
    if index == 0:
        title = "Stack push time (array)"
    elif index == 1:
        title = "Stack pop time (array)"
    elif index == 2:
        title = "Stack push time (linked list)"
    elif index == 3:
        title = "Stack pop time (linked list)"
    plt.title(title)    # 위의 인덱스 별로 그래프 타이틀 설정
    print(title+" :", time_list)    # 전체 실행시간 리스트 출력
    plt.plot(x, time_list)  # 그래프 생성
    plt.show()  # 그래프 출력
    print("Average of "+title+" :", sum(time_list)/len(time_list))  # 실행시간 평균 출력


graph(push_time_arr, 0)
graph(pop_time_arr, 1)
graph(push_time_list, 2)
graph(pop_time_list, 3)
