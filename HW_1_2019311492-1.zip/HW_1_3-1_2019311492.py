def add(item):  # 삽입 연산(enqueue)을 수행하는 함수
    q.append(item)  # q 리스트에 항목 삽입

def remove():   # 삭제 연산(dequeue)를 수행하는 함수
    if len(q) != 0: # 만약 큐가 비어있지 않다면
        item = q.pop(0) # 맨 앞의 항목 삭제
        return item # 맨 앞 항목 반환

def print_q():  # 큐 출력 함수
    print("front -> ", end="")  # front 출력
    for i in range(len(q)): # 큐의 항목 개수만큼 반복
        print('{!s:<8}'.format(q[i]), end="")   # 큐 리스트의 항목을 앞에서 하나씩 출력
    print(' <- rear')   # rear 출력

q = []  # 큐 리스트 초기화
add(1)  # 1 enqueue
add(2)  # 2 enqueue
add(3)  # 3 enqueue
add(4)  # 4 enqueue
print_q()   # 큐 출력
remove()    # dequeue
remove()    # dequeue
print_q()   # 큐 출력