def push(item): # 삽입 연산을 수행하는 함수
    stack.append(item)

def peek(): # top 항목에 접근하는 함수
    if len(stack) != 0: # 만약 스택이 비지 않았다면
        return stack[-1]    # top 항목 반환

def pop():  # 삭제 연산 수행하는 함수
    if len(stack) != 0: # 만약 스택이 비지 않았다면
        item = stack.pop(-1)    # 리스트의 가장 마지막 요소 제거 및 item에 할당
        return item # 제거한 요소 반환

stack = []  # stack 초기화
push(1) # push 연산 수행
push(2) # push 연산 수행
push(3) # push 연산 수행
print("stack :", stack) # stack 출력
print("peek :", peek()) # stack의 가장 위 요소 출력
pop()   # pop 연산 수행
print("pop 연산 후 stack :", stack)    # stack 출력

