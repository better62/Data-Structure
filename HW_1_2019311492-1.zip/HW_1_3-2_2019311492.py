class Node: # 노드 클래스 생성
    def __init__(self, item, n):    # 노드 생성자
        self.item = item    # 항목
        self.next = n   # 다음 노드 레퍼런스

def add(item):  # 삽입 연산(enqueue) 수행하는 함수
    global size # 전역변수로 사이즈 선언
    global front    # 전역변수로 front 선언
    global rear # 전역변수로 rear 선언

    new_node = Node(item, None) # 새로운 노드 형성
    if size == 0:   # 만약 큐가 비어있으면
        front = new_node    # 새로운 노드를 front로
    else:   # 큐가 비어있지 않다면
        rear.next = new_node    # rear 다음 노드를 새로운 노드로

    rear = new_node # 큐의 가장 마지막 노드를 새로운 노드로
    size += 1   # 삽입 연산이 끝나면 사이즈 1 늘리기

def remove():   # 삭제 연산(dequeue) 수행하는 함수
    global size  # 전역변수로 사이즈 선언
    global front  # 전역변수로 front 선언
    global rear  # 전역변수로 rear 선언

    if size != 0:   # 만약 큐가 비어있지 않다면
        fitem = front.item  # 큐의 가장 앞 노드의 항목을 fitem에 할당
        front = front.next  # 가장 앞 노드 다음 노드를 front로
        size -= 1   # 삭제 연산 수행 후 사이즈 1 줄이기
        if size == 0:   # 삭제 연산 수행 후 큐가 비었으면
            rear = None # rear를 None으로
        return fitem    # front의 항목 값 반환

def print_q():  # 큐 항목값 출력하는 함수
    p = front   # 큐의 가장 앞 노드를 p에 할당
    print("front: ", end="")    # front 출력
    while p:    # 큐를 순회
        if p.next != None:  # 큐의 마지막 노드가 아니면
            print(p.item, '->   ', end="")  # 항목과 화살표 출력
        else:   # 큐의 마지막 노드이면
            print(p.item, end="")   # 항목 출력
        p = p.next  # 다음 노드로 이동
    print(" : rear")    # rear 출력

front = None    # front 초기화
rear = None # rear 초기화
size = 0    # size 초기화
add(1)  # 1 enqueue
add(2)  # 2 enqueue
add(3)  # 3 enqueue
add(4)  # 4 enqueue
print_q()   # 큐 출력
remove()    # dequeue
remove()    # dequeue
print_q()   # 큐 출력