class Node: # 노드 클래스 생성
    def __init__(self, item, link): # 노드 생성자
        self.item = item    # 항목
        self.next = link    # 다음 레퍼런스

def push(item): # stack 삽입 연산 수행하는 함수
    global top  # 전역변수로 top 변수 선언(stack의 가장 위 요소)
    global size # 전역변수로 스택의 사이즈 변수 선언
    top = Node(item, top)   # top을 다음 레퍼런스로 하는 노드 생성 후 연결리스트의 첫 노드로 삽입
    size += 1   # 삽입 연산 수행 후 사이즈 1 늘이기

def peek(): # stack의 가장 위에 있는 요소 반환하는 함수
    if size != 0:   # 스택이 비어있지 않다면
        return top.item # top item 반환

def pop():  # stack 삭제 연산 수행하는 함수
    global top  # 전역변수로 top 변수 선언(stack의 가장 위 요소)
    global size  # 전역변수로 스택의 사이즈 변수 선언
    if size != 0:   # 만약 스택이 비어있지 않다면
        top_item = top.item # top item을 변수에 저장
        top = top.next  # top 다음 요소를 top으로
        size -= 1   # 삭제 연산 수행 후 사이즈 1 줄이기
        return top_item # top item 반환

def print_stack():  # 스택 요소 출력하는 함수
    print("top ->\t", end="")   # top 문자열 출력
    p = top # 스택의 top을 p에 할당
    while p:    # 스택 순환
        if p.next != None:  # 스택의 마지막 요소가 아니라면
            print(p.item, '-> ', end="")    # 항목 값과 화살표 출력
        else:   # 스택의 마지막 요소이면
            print(p.item, end="")   # 항목 값 출력
        p = p.next  # 스택의 다음 노드로 이동
        
top = None  # top 초기화
size = 0    # 사이즈 초기화
push(1) # push 연산 수행
push(2) # push 연산 수행
push(3) # push 연산 수행
print_stack() # stack 출력
print("\npeek :", peek()) # stack의 가장 위 요소 출력
pop()   # pop 연산 수행
print_stack()    # stack 출력