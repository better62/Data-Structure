class DList:    # Doubly linked list 클래스 생성
    class Node: # 노드 클래스 생성
        def __init__(self, item, prev=None, next=None):   # 노드 생성자
            self.item = item    # 항목
            self.prev = prev    # 앞 레퍼런스
            self.next = next    # 뒤 레퍼런스

    def __init__(self): # Doubly linked list 생성자
        self.head = self.Node(None, None, None) # 리스트의 head 초기화
        self.tail = self.Node(None, self.head, None)    # 리스트의 tail 초기화
        self.head.next = self.tail  # head 다음 노드를 tail 노드로
        self.size = 0   # 리스트의 사이즈를 0으로 초기화

    def size(self):  # 리스트의 사이즈를 구하는 함수
        return self.size  # 사이즈 반환

    def is_empty(self):  # 리스트가 비어있는지 확인하는 함수
        return self.size == 0  # True/False로 반환

    def insert_before(self, p, item):   # p값을 저장하는 노드 이전에 노드 삽입하는 함수
        t = p.prev  # p 이전 노드를 t에 할당
        n = self.Node(item, t, p)   # t를 이전 노드로 하고 p를 다음 노드로 하는 노드 생성
        p.prev = n  # p 앞 레퍼런스를 새롭게 생성한 노드로
        t.next = n  # t 뒤 레퍼런스를 새롭게 생성한 노드로
        self.size += 1  # 삽입이 끝나면 사이즈 1 늘리기

    def insert_after(self, p, item):    # p 다음에 노드 삽입하는 함수
        t = p.next  # p 다음 노드를 t에 할당
        n = self.Node(item, p, t)   # p를 이전 노드로 하고 t를 다음 노드로 하는 노드 생성
        t.prev = n  # t 앞 레퍼런스를 새롭게 생성한 노드로
        p.next = n  # p 뒤 레퍼런스를 새롭게 생성한 노드로
        self.size += 1  # 삽입이 끝나면 사이즈 1 늘리기

    def delete(self, x):    # x 노드 삭제하는 함수
        f = x.prev  # x의 이전 노드를 f에 할당
        r = x.next  # x의 다음 노드를 f에 할당
        f.next = r  # f의 다음 레퍼런스가 r를 가리키도록
        r.prev = f  # r의 이전 레퍼런스가 f를 가리키도록 => x를 건너뛰도록
        self.size -= 1  # 삭제가 끝나면 사이즈 1 줄이기
        return x.item # 삭제가 끝나면 x의 항목 반환

    def print_list(self):   # 리스트의 항목 값을 출력하는 함수
        if self.is_empty(): # 리스트가 비었으면
            print("리스트 비어있음")   # 리스트가 비어있음 출력
        else:   # 리스트가 비어있지 않다면
            p = self.head.next  # 가장 처음 노드를 p에 할당
            while p != self.tail:   # 리스트의 가장 마지막 노드까지 순환
                if p.next != self.tail: # 리스트의 마지막 노드가 아니라면
                    print(p.item, ' <=> ', end="")  # 해당 노드의 항목 값과 화살표 출력
                else:   # 리스트의 마지막 노드이면
                    print(p.item)   # 해당 노드의 항목 값 출력
                p = p.next  # 다음 노드로 이동


d_list = DList()    # doubly linked list 객체 생성
d_list.insert_after(d_list.head, 7) # head 뒤에 7 삽입
d_list.insert_after(d_list.head, 5) # head 뒤에 5 삽입
d_list.insert_before(d_list.tail, 3)    # tail 이전에 3 삽입
d_list.print_list() # 리스트 출력
d_list.delete(d_list.tail.prev)    # tail 이전 노드 삭제
d_list.print_list() # 리스트 출력