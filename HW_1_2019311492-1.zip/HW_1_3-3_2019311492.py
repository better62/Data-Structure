import time
import random

"""
array 기반
"""

def random_queue(n):    # n개의 요소가 있는 random 큐 생성 함수
    queue = []  # 빈 큐 선언
    for i in range(n):  # n 만큼 반복
        queue.append(random.randint(0, 1000))   # 랜덤 수 append
    return queue    # 랜덤 큐 반환

def run_time_array(): # 실행 시간 측정
    add_time = []  # add 연산 실행 시간 저장하는 리스트
    remove_time = []   # remove 연산 실행 시간 저장하는 리스트
    # 큐의 요소 개수는 1부터 10000까지
    for i in range(1, 10001):
        queue = random_queue(i) # i개 요소의 랜덤 큐 생성
        start = time.perf_counter() # add 연산 전 시간 측정
        queue.append(1)  # add 연산
        end = time.perf_counter()   # add 연산 후 시간 측정
        add_time.append(end-start) # 측정한 시간 append
        start = time.perf_counter() # remove 연산 전 시간 측정
        queue.pop(0)   # remove 연산
        end = time.perf_counter()   # remove 연산 후 시간 측정
        remove_time.append(end-start)  # 측정한 시간 append
    return add_time, remove_time  # 각 리스트를 반환

add_time_arr, remove_time_arr = run_time_array()    # 실행 시간 측정 함수 호출

#######################################################
#######################################################
#######################################################
"""
linked list 기반
"""

class Node: # 노드 클래스 생성
    def __init__(self, item, n):    # 노드 생성자
        self.item = item    # 항목
        self.next = n   # 다음 노드 레퍼런스

def add(item):  # 삽입 연산(enqueue) 수행하는 함수
    global size # 전역변수로 사이즈 선언
    global front    # 전역변수로 front 선언
    global rear # 전역변수로 rear 선언

    new_node = Node(item, None) # 새로운 노드 형성
    if size == 0:   # 만약 큐가 비어있으면
        front = new_node    # 새로운 노드를 front로
    else:   # 큐가 비어있지 않다면
        rear.next = new_node    # rear 다음 노드를 새로운 노드로

    rear = new_node # 큐의 가장 마지막 노드를 새로운 노드로
    size += 1   # 삽입 연산이 끝나면 사이즈 1 늘리기

def remove():   # 삭제 연산(dequeue) 수행하는 함수
    global size  # 전역변수로 사이즈 선언
    global front  # 전역변수로 front 선언
    global rear  # 전역변수로 rear 선언

    if size != 0:   # 만약 큐가 비어있지 않다면
        fitem = front.item  # 큐의 가장 앞 노드의 항목을 fitem에 할당
        front = front.next  # 가장 앞 노드 다음 노드를 front로
        size -= 1   # 삭제 연산 수행 후 사이즈 1 줄이기
        if size == 0:   # 삭제 연산 수행 후 큐가 비었으면
            rear = None # rear를 None으로
        return fitem    # front의 항목 값 반환

def random_queue_list(n):    # n개의 요소가 있는 random queue 생성 함수
    global size  # 전역변수로 사이즈 선언
    global front  # 전역변수로 front 선언
    global rear  # 전역변수로 rear 선언

    front = None  # front 초기화
    rear = None  # rear 초기화
    size = 0  # size 초기화

    for i in range(n):  # n 만큼 반복
        add(random.randint(0, 1000))   # 랜덤 수 add

def run_time_list(): # 실행 시간 측정
    add_time = []  # add 연산 실행 시간 저장하는 리스트
    remove_time = []   # pop 연산 실행 시간 저장하는 리스트
    # queue의 요소 개수는 1부터 10000까지
    for i in range(1, 10001):
        random_queue_list(i) # i개 요소의 랜덤 큐 생성
        start = time.perf_counter() # add 연산 전 시간 측정
        add(1)  # add 연산
        end = time.perf_counter()   # add 연산 후 시간 측정
        add_time.append(end-start) # 측정한 시간 append
        start = time.perf_counter() # remove 연산 전 시간 측정
        remove()   # remove 연산
        end = time.perf_counter()   # remove 연산 후 시간 측정
        remove_time.append(end-start)  # 측정한 시간 append
    return add_time, remove_time  # 각 리스트를 반환

add_time_list, remove_time_list = run_time_list()    # 실행 시간 측정 함수 호출

"""
각 실행시간 비교를 위해 그래프 그리기
"""
import matplotlib.pyplot as plt

x = []
for i in range(1, 10001):   # 그래프 x 축 생성
    x.append(i)

def graph(time_list, index):    # graph와 평균 실행 시간 구하는 함수
    if index == 0:
        title = "Queue add time (array)"
    elif index == 1:
        title = "Queue remove time (array)"
    elif index == 2:
        title = "Queue add time (linked list)"
    elif index == 3:
        title = "Queue remove time (linked list)"
    plt.title(title)    # 위의 인덱스 별로 그래프 타이틀 설정
    print(title+" :", time_list)    # 전체 실행시간 리스트 출력
    plt.plot(x, time_list)  # 그래프 생성
    plt.show()  # 그래프 출력
    print("Average of "+title+" :", sum(time_list)/len(time_list))  # 실행시간 평균 출력


graph(add_time_arr, 0)
graph(remove_time_arr, 1)
graph(add_time_list, 2)
graph(remove_time_list, 3)