class SList:    # Singly linked list 클래스 생성
    class Node: # 노드 클래스 생성
        def __init__(self, item, link): # 노드 생성자
            self.item = item    # 항목
            self.next = link    # 다음 노드 레퍼런스

    def __init__(self): # Singly linked list 생성자
        self.head = None    # head
        self.size = 0   # 항목 수

    def size(self): # 리스트의 사이즈를 구하는 함수
        return self.size    # 사이즈 반환

    def is_empty(self): # 리스트가 비어있는지 확인하는 함수
        return self.size == 0   # True/False로 반환

    def insert_front(self, item):   # 리스트의 가장 앞쪽에 노드 삽입 함수
        if self.is_empty(): # 만약에 리스트가 비었다면
            self.head = self.Node(item, None)   # 해당 노드를 head로
        else:   # 리스트에 데이터가 있으면
            # head가 해당 노드를 가리키도록 하고 해당 노드가 기존 head를 참조
            self.head = self.Node(item, self.head)
        self.size += 1  # 삽입이 끝나면 사이즈 1 늘리기

    def insert_after(self, item, p):    # p 다음에 노드 삽입 함수
        # item을 항목으로 가지고 p 다음 노드를 참조로 하는 노드를 생성한 후 p 다음에 연결되도록
        p.next = SList.Node(item, p.next)
        self.size += 1  # 삽입이 끝나면 사이즈 1 늘리기

    def delete_front(self): # 가장 앞 노드 삭제 함수
        if self.is_empty(): # 만약에 리스트가 비었으면
            raise EmptyError("Underflow")   # Empty error 발생
        else:   # 리스트가 비어있지 않다면
            self.head = self.head.next  # head를 기존 head 다음 노드로
            self.size -= 1  # 삭제가 끝나면 사이즈 1 줄이기

    def delete_after(self, p):  # p 다음 노드 삭제 함수
        if self.is_empty():  # 만약에 리스트가 비었으면
            raise EmptyError("Underflow")  # Empty error 발생
        t = p.next  # t가 p 다음 노드를 가리키도록
        p.next = t.next # p 다음 노드에 t 다음 노드를 연결 => p 다음 노드를 건너뜀
        self.size -= 1  # 삭제가 끝나면 사이즈 1 줄이기

    def search(self, target):   # target 탐색 함수
        p = self.head   # 리스트의 가장 앞 노드 할당
        for k in range(self.size):  # 리스트 사이즈만큼 반복
            if target == p.item:    # 만약 target과 노드의 항목 값이 같으면
                return k    # 해당 노드 반환 (탐색 성공)
            p = p.next  # target과 해당 노드의 항목 값이 다를 경우 다음 노드로 이동
        return None # 리스트를 모두 탐색해도 못 찾을 경우 None 반환 (탐색 실패)

    def print_list(self):   # 리스트 항목 출력 함수
        p = self.head   # 리스트의 가장 앞 노드 할당
        while p:    # 리스트의 가장 처음 노드부터 끝까지 반복
            if p.next != None:  # 만약 p 다음 노드가 존재하면
                print(p.item, '->', end="") # 항목값과 화살표 출력
            else:   # 만약 p가 마지막 노드이면
                print(p.item)   # 항목값 출력
            p = p.next  # p에 p 다음 노드 할당

class EmptyError(Exception):    # underflow시 에러 처리하는 클래스
    pass

s_list = SList()    # singly linked list 객체 생성
s_list.insert_front(1)  # 1을 리스트 앞에 삽입
s_list.insert_front(2)  # 2를 리스트 앞에 삽입
s_list.insert_front(3)  # 3를 리스트 앞에 삽입
s_list.insert_front(4)  # 4를 리스트 앞에 삽입
s_list.print_list() # 리스트 출력

print("두 번째 요소 삭제 후 리스트")
s_list.delete_after(s_list.head)    # 두 번째 요소 삭제
s_list.print_list() # 리스트 출력

print("첫 번째 요소 삭제 후 리스트")
s_list.delete_front()    # 첫 번째 요소 삭제
s_list.print_list() # 리스트 출력

print("첫 노드로 7, 8 삽입 후 리스트")
s_list.insert_front(7)  # 7을 맨 앞에 삽입
s_list.insert_front(8)  # 8을 맨 앞에 삽입
s_list.print_list() # 리스트 출력

print("두 번째 노드 뒤에 5 삽입 후 리스트")
s_list.insert_after(5, s_list.head.next)    # 리스트의 헤드 다음(두 번째 요소 뒤)에 5 삽입
s_list.print_list() # 리스트 출력

print("2 찾기")
a = s_list.search(2)    # 요소 2의 인덱스 찾기
print(a)    # 인덱스 출력